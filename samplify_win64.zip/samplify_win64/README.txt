[H] - Stop Audio
[G] - Replay Audio from Cue Point

All preferences and files are saved under the OS's application properties location. This includes preferences to modify the look and feel of the application.

Incomplete Features:
Sample Color - Set indivitual colors for each sample to be labeled by
Sorting Methods - Some sorting methods are incomplete [Newest, Oldest, Random] are all working properly.
Full Async Functionality - The UI will sometimes hang as the process might not have been converted to async functionality.

Known Bugs:

Windows:
-no known bugs currently, except unfinished features

Mac:
- The repaint function of the application varies from Windows, does not draw the line while audio plays automatically, must move mouse over app to continue visual updates.
- Most testing in development was done on windows, might be more unnoticed bugs.